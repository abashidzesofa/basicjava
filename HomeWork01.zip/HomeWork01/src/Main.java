public class Main {
    public static void main(String[] args) {
        System.out.println("Задание 3a:");
        System.out.println("");
        System.out.println("Суворова");
        System.out.println("Анастасия");
        System.out.println("Ивановна");
        System.out.println(36);
        System.out.println(169);
        System.out.println();
        System.out.println("Абашидзе");
        System.out.println("Софа");
        System.out.println("Миндиевна");
        System.out.println(26);
        System.out.println(168);
        System.out.println();
        System.out.println("Кузьменко");
        System.out.println("Александр");
        System.out.println("Стапанович");
        System.out.println(42);
        System.out.println(183);
        System.out.println("");
        System.out.println("Задание 3b:");
        System.out.println("");
        System.out.printf("3.2222222 заменим на - %.2f", 3.222222);
        System.out.println("");
        System.out.printf("4.3333333 заменим на - %.2f", 4.333333);
        System.out.println("");
        System.out.printf("5.4444444 заменим на - %.2f", 5.444444);
        System.out.println("");
        System.out.println("");
        System.out.println("Задание 3c:");
        System.out.println("");
        System.out.print("|");
        System.out.print("--------");
        System.out.print("|");
        System.out.println("");
        System.out.print("|");
        System.out.print("--------");
        System.out.print("|");


    }

}